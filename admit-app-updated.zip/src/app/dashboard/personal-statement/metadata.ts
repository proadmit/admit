import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Personal Statement - Admit App",
  description: "Write and edit your college application personal statement",
}; 