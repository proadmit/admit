
export default function PrivacyPolicy() {
  return (
    <main className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Privacy Policy</h1>
      <p>We respect your privacy. This page will outline how your data is used and protected on our platform.</p>
    </main>
  );
}
