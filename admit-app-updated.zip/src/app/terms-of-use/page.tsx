
export default function TermsOfUse() {
  return (
    <main className="max-w-2xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Terms of Use</h1>
      <p>By using our platform, you agree to the following terms and conditions. Please read them carefully.</p>
    </main>
  );
}
